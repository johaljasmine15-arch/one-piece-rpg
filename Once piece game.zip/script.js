// IMAGE SIZE FIX
const imageStyle = document.createElement("style");
imageStyle.textContent = `
  #scene-img {
    width: 100%;
    max-width: 500px;
    height: 300px;
    object-fit: contain;
    display: block;
    margin: 0 auto;
  }
`;
document.head.appendChild(imageStyle);


// GAME STATE
let hp = 100;
let gold = 50;
let hasWeapon = false;
let gameOver = false;
let maxHp = 100;
let characterChosen = false;
let gameStarted = false;

// Going Merry activities
let crewTrainingDone = false;
let navigationHelpDone = false;

// One-time rewards
let bushesSearched = false;
let caveRewardClaimed = false;
let dinosaurDefeated = false;


// START GAME
function startGame() {
  if (!characterChosen) {
    document.getElementById("message").textContent =
      "Please choose a character first!";
    return;
  }

  if (gameStarted) return;

  const nameInput = document.getElementById("name-input");
  const playerName = nameInput.value.trim() || "Adventurer";

  gameStarted = true;

  document.querySelectorAll("#setup .card button").forEach(button => {
    button.disabled = true;
  });

  document.getElementById("welcome").textContent =
    "Welcome, " + playerName + "! Your pirate adventure begins!";

    // Hide character selection
  document.getElementById("setup").style.display = "none";

  // Show game scene
  document.getElementById("scene").style.display = "block";

  // Hide test buttons
  document.getElementById("test-panel").style.display = "none";

  updateUI();
  goCrossroad();
}


// UPDATE PLAYER INFORMATION
function updateUI() {
  hp = Math.max(0, Math.min(hp, maxHp));

  document.getElementById("hp-text").textContent = hp;
  document.getElementById("gold-text").textContent = gold;

  document.getElementById("weaponText").textContent =
    hasWeapon ? "1" : "None";

  const hpBar = document.getElementById("hp-bar-fill");

  hpBar.style.width = (hp / maxHp * 100) + "%";

  if (hp <= 30) {
    hpBar.classList.add("danger");
  } else {
    hpBar.classList.remove("danger");
  }

  checkGameOver();
}


// GAME OVER
function checkGameOver() {
  if (hp <= 0 && !gameOver) {
    hp = 0;
    gameOver = true;

    document.getElementById("hp-text").textContent = 0;

    document.getElementById("scene-text").textContent =
      "GAME OVER! Your pirate adventure has ended.";

    document.getElementById("scene-img").src =
      "images/gameover.png";

    document.getElementById("scene-img").alt = "Game Over";

    document.getElementById("message").textContent =
      "You ran out of health! Better luck next time.";

    document.getElementById("btn1").textContent = "Play Again";

    document.getElementById("btn1").onclick = function() {
      location.reload();
    };

    document.getElementById("btn2").textContent = "";
    document.getElementById("btn2").onclick = null;
  }
}


// WIN GAME
function winGame() {
  if (gameOver) return;

  gameOver = true;

  document.getElementById("scene-text").textContent =
    "YOU WIN! You successfully entered the Grand Line and joined the Straw Hat Pirates!";

  document.getElementById("scene-img").src =
    "images/victory.png";

  document.getElementById("scene-img").alt = "Victory";

  document.getElementById("message").textContent =
    "Congratulations, pirate! You completed your adventure!";

  document.getElementById("btn1").textContent = "Play Again";

  document.getElementById("btn1").onclick = function() {
    location.reload();
  };

  document.getElementById("btn2").textContent = "";
  document.getElementById("btn2").onclick = null;
}


// CHOOSE WARRIOR
function chooseWarrior() {
  if (gameStarted) return;

  hp = 150;
  maxHp = 150;
  gold = 50;
  hasWeapon = false;
  characterChosen = true;

  document.getElementById("hero-img").src =
    "images/warrior.png";

  document.getElementById("hero-img").alt = "Warrior";

  document.getElementById("class-desc").textContent =
    "Warrior: strong and brave. Good at fighting. 150 HP and 50 Gold.";

  document.getElementById("message").textContent =
    "Warrior selected! You can switch characters before starting.";

  updateUI();
}


// CHOOSE MAGE
function chooseMage() {
  if (gameStarted) return;

  hp = 80;
  maxHp = 80;
  gold = 100;
  hasWeapon = false;
  characterChosen = true;

  document.getElementById("hero-img").src =
    "images/mage.png";

  document.getElementById("hero-img").alt = "Mage";

  document.getElementById("class-desc").textContent =
    "Mage: clever and quick. Good at magic. 80 HP and 100 Gold.";

  document.getElementById("message").textContent =
    "Mage selected! You can switch characters before starting.";

  updateUI();
}


// SHOW SCENE
function renderScene(text, img, btn1Text, btn1Func, btn2Text, btn2Func) {
  if (gameOver) return;

  document.getElementById("scene-text").textContent = text;
  document.getElementById("scene-img").src = img;
  document.getElementById("scene-img").alt = text;
  document.getElementById("message").textContent = "";

  document.getElementById("btn1").textContent = btn1Text;
  document.getElementById("btn1").onclick = btn1Func;

  document.getElementById("btn2").textContent = btn2Text;
  document.getElementById("btn2").onclick = btn2Func;
}


// CROSSROAD
function goCrossroad() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You stand at a crossroad. Where will your pirate adventure take you?",
    "images/crossroad.png",
    "Go to the forest",
    goForest,
    "Go to the village",
    goVillage
  );
}


// SCENE 1: FOREST
function goForest() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You enter a mysterious forest. Tall trees block the sunlight. You notice a dark cave and a strange footpath.",
    "images/forest.png",
    "Explore deeper into the forest",
    goCave,
    "Follow the strange footpath",
    goFootpath
  );
}


// SCENE 2: FOOTPATH
function goFootpath() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You follow the footpath through the forest. You can see the beach in the distance. What will you do?",
    "images/footpath.png",
    "Continue to the beach",
    goBeach,
    "Search nearby bushes for treasure",
    searchBushes
  );
}


// SEARCH BUSHES 
function searchBushes() {
  if (gameOver || !gameStarted) return;

  let message;

  if (!bushesSearched) {
    bushesSearched = true;
    gold += 10;

    message = "You search the bushes and discover 10 gold coins!";
    updateUI();
  } else {
    message =
      "You have already searched these bushes. There is no more treasure here!";
  }

  renderScene(
    message,
    "images/footpath.png",
    "Go to the beach",
    goBeach,
    "Return to the forest",
    goForest
  );
}


// SCENE 3: CAVE
function goCave() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You enter a dark cave. Suddenly, a dangerous dinosaur appears! What will you do?",
    "images/dinosaur.png",
    "Fight the dinosaur (requires sword)",
    fightDinosaur,
    "Search for another way through",
    findCavePath
  );
}


// FIGHT DINOSAUR
function fightDinosaur() {
  if (gameOver || !gameStarted) return;

  if (dinosaurDefeated) {
    renderScene(
      "The dinosaur has already been defeated! The cave is now safe.",
      "images/dinosaur.png",
      "Continue to the footpath",
      goFootpath,
      "Return to the forest",
      goForest
    );
    return;
  }

  if (hasWeapon) {
    dinosaurDefeated = true;
    gold += 20;
    updateUI();

    renderScene(
      "You defeat the dinosaur using your sword! You discover 20 gold coins behind it.",
      "images/dinosaur.png",
      "Continue to the footpath",
      goFootpath,
      "Return to the forest",
      goForest
    );
  } else {
    hp = Math.max(0, hp - 30);
    updateUI();

    if (gameOver) return;

    renderScene(
      "You tried fighting the dinosaur without a sword and lost 30 HP! You need a weapon for this battle.",
      "images/dinosaur.png",
      "Find another way through",
      goFootpath,
      "Go to the village to buy a sword",
      goVillage
    );
  }
}


// FIND ANOTHER CAVE PATH 
function findCavePath() {
  if (gameOver || !gameStarted) return;

  let message;

  if (!caveRewardClaimed) {
    caveRewardClaimed = true;
    gold += 10;

    message =
      "You discover a hidden passage inside the cave. You find 10 gold coins and escape safely!";

    updateUI();
  } else {
    message =
      "You use the hidden passage to escape the cave safely. You have already collected its treasure!";
  }

  renderScene(
    message,
    "images/dinosaur.png",
    "Follow the passage to the footpath",
    goFootpath,
    "Return to the forest",
    goForest
  );
}


// SCENE 4: BEACH
function goBeach() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You arrive at a beautiful beach. You notice a small boat near the shore. What will you do?",
    "images/beach.png",
    "Walk towards the boat",
    goBoat,
    "Go back to the footpath",
    goFootpath
  );
}


// SCENE 5: BOAT
function goBoat() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You reach the boat and notice a mysterious pirate ship approaching. What will you do?",
    "images/boat.png",
    "Sail towards the approaching ship",
    goGoingMerry,
    "Hide and wait for the ship to come closer",
    hideFromShip
  );
}


// HIDE FROM SHIP
function hideFromShip() {
  if (gameOver || !gameStarted) return;

  hp = Math.max(0, hp - 20);
  updateUI();

  if (gameOver) return;

  renderScene(
    "You hide, but the approaching Marines discover your boat! You escape, but lose 20 HP. Another ship arrives to help you!",
    "images/marines.png",
    "Board the rescue ship",
    goGoingMerry,
    "Return to the beach",
    goBeach
  );
}


// SCENE 6: GOING MERRY
function goGoingMerry() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You climb aboard the Going Merry! You meet Luffy and the Straw Hat Pirates. Luffy invites you on their adventure!",
    "images/going-merry.png",
    "Accept Luffy's request to join his crew",
    joinStrawHats,
    "Challenge Zoro to a friendly fight",
    challengeZoro
  );
}


// JOIN STRAW HATS
function joinStrawHats() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "Luffy happily welcomes you to the Straw Hat Pirates! He introduces you to his crew and everyone is excited to have a new member!",
    "images/luffy-welcome.png",
    "Meet the crew",
    meetCrew,
    "Talk to Luffy",
    talkToLuffy
  );
}


// MEET THE CREW
function meetCrew() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You meet the Straw Hat crew! Zoro says he hopes you can keep up with his training. Nami reminds everyone to be careful with the ship's money. Usopp tells you about his amazing adventures, and Sanji offers to make you something to eat. You feel like part of the crew!",
    "images/strawhat-crew.png",
    "Train with Zoro",
    trainWithZoro,
    "Help Nami with navigation",
    helpNami
  );
}


// TALK TO LUFFY
function talkToLuffy() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You sit with Luffy on the Going Merry. He tells you that the Grand Line is full of amazing islands, strong pirates and exciting adventures. He says he is glad you joined his crew!",
    "images/luffy-welcome.png",
    "Meet the rest of the crew",
    meetCrew,
    "Get ready to set sail",
    prepareToSail
  );
}


// TRAIN WITH ZORO 
function trainWithZoro() {
  if (gameOver || !gameStarted) return;

  let trainingMessage = "";

  if (crewTrainingDone) {
    trainingMessage =
      "You have already trained with Zoro. He tells you that you are improving and gives you a nod of approval!";
  } else {
    crewTrainingDone = true;

    if (hasWeapon) {
      gold += 10;

      trainingMessage =
        "You practise sword skills with Zoro. He is impressed by your effort and gives you 10 gold coins as a reward!";
    } else {
      trainingMessage =
        "You practise basic fighting moves with Zoro. He tells you that you have potential and should keep training!";
    }

    updateUI();
  }

  renderScene(
    trainingMessage,
    "images/zoro-training.png",
    "Help Nami with navigation",
    helpNami,
    "Talk to Luffy",
    talkToLuffy
  );
}



// HELP NAMI 
function helpNami() {
  if (gameOver || !gameStarted) return;

  let navigationMessage = "";

  if (navigationHelpDone) {
    navigationMessage =
      "You have already helped Nami with navigation. She thanks you for your help and checks the map again.";
  } else {
    navigationHelpDone = true;
    gold += 10;

    navigationMessage =
      "Nami shows you the map and asks you to help plan the route. You successfully help her find the safest direction! She rewards you with 10 gold coins.";

    updateUI();
  }

  renderScene(
    navigationMessage,
    "images/nami-navigation.png",
    "Train with Zoro",
    trainWithZoro,
    "Get ready to set sail",
    prepareToSail
  );
}


// PREPARE TO SAIL
function prepareToSail() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "The Straw Hat crew gathers on the Going Merry. Luffy is excited, Nami checks the map, Zoro gets ready for the journey and the ship begins moving towards the Grand Line!",
    "images/going-merry.png",
    "Set sail towards the Grand Line",
    goGrandLine,
    "Talk to Luffy one more time",
    talkToLuffy
  );
}


// CHALLENGE ZORO
function challengeZoro() {
  if (gameOver || !gameStarted) return;

  if (hasWeapon) {
    renderScene(
      "You challenge Zoro to a friendly sword fight. He is impressed by your skills and agrees to let you join the crew!",
      "images/zoro-fight.png",
      "Join the Straw Hats",
      joinStrawHats,
      "Talk to Luffy",
      talkToLuffy
    );
  } else {
    renderScene(
      "Zoro notices you don't have a sword. He tells you to keep training. Luffy still invites you to join the crew!",
      "images/zoro-fight.png",
      "Join the Straw Hats",
      joinStrawHats,
      "Sail towards the Grand Line",
      goGrandLine
    );
  }
}


// SCENE 7: GRAND LINE
function goGrandLine() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You reach Reverse Mountain! The entrance to the Grand Line is ahead, but the journey is dangerous. What will you do?",
    "images/grand-line.png",
    "Face the final challenge",
    faceFinalChallenge,
    "Find another way through",
    alternateRoute
  );
}


// FINAL CHALLENGE
function faceFinalChallenge() {
  if (gameOver || !gameStarted) return;

  if (hasWeapon) {
    winGame();
  } else {
    hp = Math.max(0, hp - 30);
    updateUI();

    if (gameOver) return;

    renderScene(
      "The final challenge is difficult without a sword! You lose 30 HP but manage to reach the Grand Line.",
      "images/grand-line.png",
      "Continue your adventure",
      winGame,
      "Try the alternate route",
      alternateRoute
    );
  }
}


// ALTERNATE ROUTE
function alternateRoute() {
  if (gameOver || !gameStarted) return;

  hp = Math.max(0, hp - 10);
  updateUI();

  if (gameOver) return;

  renderScene(
    "You discover a hidden route around the final challenge. It costs you 10 HP, but you successfully reach the Grand Line!",
    "images/grand-line.png",
    "Celebrate with the Straw Hats",
    winGame,
    "Face the final challenge",
    faceFinalChallenge
  );
}


// VILLAGE
function goVillage() {
  if (gameOver || !gameStarted) return;

  renderScene(
    "You arrive at a quiet village. You notice a shop where you can buy supplies.",
    "images/village.png",
    "Visit the shop",
    goShop,
    "Return to the crossroad",
    goCrossroad
  );
}


// SHOP
function goShop() {
  if (gameOver || !gameStarted) return;

  if (hasWeapon) {
    renderScene(
      "Welcome to the shop! You already own a sword.",
      "images/shop.png",
      "Check my sword",
      showSword,
      "Return to the village",
      goVillage
    );
  } else {
    renderScene(
      "Welcome to the shop! A sword costs 50 gold. You have " +
        gold + " gold.",
      "images/shop.png",
      "Buy sword (50 gold)",
      buySword,
      "Return to the village",
      goVillage
    );
  }
}


// BUY SWORD
function buySword() {
  if (gameOver || !gameStarted) return;

  if (hasWeapon) {
    document.getElementById("message").textContent =
      "You already have a sword!";
    return;
  }

  if (gold >= 50) {
    gold -= 50;
    hasWeapon = true;

    updateUI();

    renderScene(
      "You bought a sword! Weapon: 1. Your sword is now in your inventory.",
      "images/shop.png",
      "Check my sword",
      showSword,
      "Continue adventure",
      goCrossroad
    );
  } else {
    document.getElementById("message").textContent =
      "Not enough gold! You need 50 gold to buy a sword, but you only have " +
      gold + " gold.";

    document.getElementById("scene-text").textContent =
      "You cannot afford the sword yet. Find more gold and come back!";
  }
}


// CHECK INVENTORY
function showSword() {
  if (gameOver || !gameStarted) return;

  renderScene(
    hasWeapon
      ? "Inventory: Weapon: 1 (Sword owned!)"
      : "Inventory: Weapon: None",
    "images/shop.png",
    "Return to the shop",
    goShop,
    "Continue adventure",
    goCrossroad
  );
}



// EXTRA ADVENTURE ACTIONS
function stepOnTrap() {
  if (gameOver || !gameStarted) return;

  hp = Math.max(0, hp - 20);
  updateUI();
}


function gainGold(amount) {
  if (gameOver || !gameStarted) return;

  if (typeof amount !== "number" || amount <= 0) return;

  gold += amount;
  updateUI();
}


function drinkPotion() {
  if (gameOver || !gameStarted) return;

  if (gold >= 10) {
    gold -= 10;
    hp = Math.min(maxHp, hp + 30);

    document.getElementById("message").textContent =
      "You drank a potion and restored your health!";
  } else {
    document.getElementById("message").textContent =
      "Not enough gold! You need 10 gold to buy a potion.";
  }

  updateUI();
}

// Hide game scene at the beginning
document.getElementById("scene").style.display = "none";

// Hide test buttons
document.getElementById("test-panel").style.display = "none";

// INITIAL STATUS
updateUI();
